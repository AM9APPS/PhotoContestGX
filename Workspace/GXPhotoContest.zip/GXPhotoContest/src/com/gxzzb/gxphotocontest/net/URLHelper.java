package com.gxzzb.gxphotocontest.net;

public class URLHelper {
	// base url
	private static final String URL_GX_CHANNEL = "http://news.ngzb.com.cn/channel/2013/gx/";
	//url
	public static final String URL_SJ_LIST = URL_GX_CHANNEL + "sj_list.php";
	public static final String URL_SJ_ADD = URL_GX_CHANNEL + "sj_add.php";
	public static final String URL_SJ_VIEW = URL_GX_CHANNEL + "sj_view.php";
	public static final String URL_SJ_TP = URL_GX_CHANNEL + "sj_tp.php";
	public static final String URL_SJ_PERSONAL = URL_GX_CHANNEL
			+ "sj_personal.php";
	public static final String URL_SJ_CKTEL = URL_GX_CHANNEL + "sj_cktel.php";

}
