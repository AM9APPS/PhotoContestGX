package com.gxzzb.gxphotocontest.ui.photoshow;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

public class ViewPhotoflowitem extends View {

	public ViewPhotoflowitem(Context context) {
		super(context);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
	}
    
}
