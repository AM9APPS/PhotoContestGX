package com.gxzzb.gxphotocontest.bean;

public class BeanImageArrayitem {

	private String tu;
	private String tusm;
	private int tuid;
	private int tpnum;

	public String getTu() {
		return tu;
	}

	public void setTu(String tu) {
		this.tu = tu;
	}

	public String getTusm() {
		return tusm;
	}

	public void setTusm(String tusm) {
		this.tusm = tusm;
	}

	public int getTuid() {
		return tuid;
	}

	public void setTuid(int tuid) {
		this.tuid = tuid;
	}

	public int getTpnum() {
		return tpnum;
	}

	public void setTpnum(int tpnum) {
		this.tpnum = tpnum;
	}

}
