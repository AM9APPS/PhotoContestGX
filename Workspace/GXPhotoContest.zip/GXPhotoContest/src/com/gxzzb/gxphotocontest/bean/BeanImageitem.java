package com.gxzzb.gxphotocontest.bean;

public class BeanImageitem {

	private int id;
	private String tu;
	private String tusm;
	private int tuid;
	private int tpnum;
	private String sj;
	private String dz;
	private int did;
	private int tuw;
	private int tuh;

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTu() {
		return tu;
	}

	public void setTu(String tu) {
		this.tu = tu;
	}

	public String getTusm() {
		return tusm;
	}

	public void setTusm(String tusm) {
		this.tusm = tusm;
	}

	public int getTuid() {
		return tuid;
	}

	public void setTuid(int tuid) {
		this.tuid = tuid;
	}

	public int getTpnum() {
		return tpnum;
	}

	public void setTpnum(int tpnum) {
		this.tpnum = tpnum;
	}

	public String getSj() {
		return sj;
	}

	public void setSj(String sj) {
		this.sj = sj;
	}

	public String getDz() {
		return dz;
	}

	public void setDz(String dz) {
		this.dz = dz;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public int getTuw() {
		return tuw;
	}

	public void setTuw(int tuw) {
		this.tuw = tuw;
	}

	public int getTuh() {
		return tuh;
	}

	public void setTuh(int tuh) {
		this.tuh = tuh;
	}

}
